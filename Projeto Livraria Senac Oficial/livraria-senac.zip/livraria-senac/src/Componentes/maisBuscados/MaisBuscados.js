import { useEffect, useState } from "react"
import { Subtitulo, Titulo } from "../styles/Textos";
import { Card, Div } from "../styles/Conteiner";
import {ImagemCard }  from "../styles/Imagem";

const MaisBuscados = () => {
    const [livros, setLivros]=useState ([]);
    useEffect(()=>{
        const buscarLivros = async () => {
            try{
                const resposta = await fetch ('http://localhost:8080/livros');
                const dados = await resposta.json();
                console.log(dados);
                setLivros(dados);
            }catch (error){
                console.error(error);
            }
        }
        buscarLivros();
    }, []);
    return(
        <>
            <Div>
            {livros.map((livro)=> {
                return(
                <>
                    <Card >
                        <Titulo>{livro.titulo}</Titulo> 
                        <Subtitulo>{livro.autor}</Subtitulo>
                        <ImagemCard src={livro.Imagen}/>
                        <h3>{livro.preco}</h3>
                    </Card>
                    
                
                </>
                )
            })}
            </Div>
            
        </>
    )
}
export default MaisBuscados; 