import styled from "styled-components";

export const ImagemLogo = styled.img`
    width: 96px;
    height:auto;
`;

export const ImagemCard = styled.img`
    width: 200px;
    height: 290px;
    `
