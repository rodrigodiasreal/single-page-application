import './App.css';
import { Parragrafo, Subtitulo, Titulo } from './Componentes/styles/Textos';

import MenuBar from './Componentes/navbar/Menu';
import MaisBuscados from './Componentes/maisBuscados/MaisBuscados';
import Pesquisa from './Componentes/pesquisa/Pesquisa';


function App() {
  return (
    <div className="App">
      <MenuBar/>
      <header className="App-header">
        <Pesquisa/>
      </header>
      <MaisBuscados>
        
      </MaisBuscados>

    </div>
  );
}

export default App;
