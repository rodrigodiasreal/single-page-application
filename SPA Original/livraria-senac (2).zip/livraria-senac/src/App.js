import { Route, Routes } from 'react-router-dom';
import './App.css';
import MaisBuscados from './Componentes/maisBuscados/MaisBuscados';
import MenuBar from './compnentes/navbar/Menu'
import Pesquisa from './componentes/pesquisa/Pesquisa';
import Cadastro from './componentes/cadastro/cadastro';

function App() {
  return (
    <div className="App">
      <MenuBar />
      <Routes>
        <Route path='/' element={
          <>
            <header className="App-header">
              <Pesquisa />
            </header>
            <MaisBuscados />
          </>
        }/>
        <Route path='/cadastro' element={<Cadastro />} />
      </Routes>
    </div>
  );
}

export default App;