import styled from "styled-components";

export const Menu= styled.nav`
display:flex;
height: 70px;
background-color:white;
align-items:center;
justify-content: space-around;

`;

export const Card = styled.div`
margin: 10px;
`

export const Div = styled.div`
display:flex;
flex-direction: ${props => props.direcao || 'row'};
width:100%;
justify-content: center;
`
