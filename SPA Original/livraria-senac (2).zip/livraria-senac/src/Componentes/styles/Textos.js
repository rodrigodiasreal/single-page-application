import styled from "styled-components";

//Nossos estilos para os textos (Titulos,subtitulos...)

export const Titulo = styled.h1`
    font-size:${props => props.tamanho || '32px'}; 
    color: ${props => props.cor || 'while'};
    line-weight:1.5rem;

`;
export const Titulo2 = styled.h1`
    font-size:32px;
    color: red;
    line-weight:1.5rem;

`;
export const Subtitulo = styled.h2`
    font-size:22px;
    color: ${props => props.corSub || 'blackS'};
    line-weight:1.5rem;

`;
export const Parragrafo = styled.p`
    font-size:12px;
    color: ${props => props.corPar || 'white'};
    line-weight:1.0rem;
    margin-left: 150px;
    margin-rigth: 180px;

`;

export const Input = styled.input`
width: 600px;
height:30px;
border-radius: 5px;
border: 1px solid black;
padding:12px;
background-color:#fff;
`;