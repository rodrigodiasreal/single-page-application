import { ImagemLogo } from "../styles/Imagem";
import { Lista } from "../styles/Listas";
import { Item } from "../styles/Listas";
import { Menu } from "../styles/Conteiner";

const lista = ['Lanzamientos', 'Blog','Fale Conosco'];

function MenuBar(){
    return <Menu>
        <ImagemLogo src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Senac_logo.svg/1200px-Senac_logo.svg.png"/>
        <Lista>
            {
                lista.map((item)=>{ <Item>{item}</Item>})
            }
        </Lista>
    </Menu>
}

export default MenuBar;
