import { Subtitulo, Titulo } from "../styles/Textos";
import { Card, Div } from "../styles/Conteiner";
import {ImagemCard }  from "../styles/Imagem";



const Resultado =({livros})=>{
    if(livros.lenght === 0){
        return <p>Nenhum livro encontrado</p>
    }
    return(
        <Div>
            {livros.map((livro)=> {
                return(
                <>
                    <Card >
                        <Titulo>{livro.titulo}</Titulo> 
                        <Subtitulo>{livro.autor}</Subtitulo>
                        <ImagemCard src={livro.Imagen}/>
                        <h3>{livro.preco}</h3>
                    </Card>
                    
                
                </>
                )
            })}
            </Div>
    )
}

export default Resultado;