import { useState } from "react"
import { Div } from "../styles/Conteiner"
import { Parragrafo, Titulo , Input} from "../styles/Textos"
import Resultado from "./Resultado";


const Pesquisa = () => {
    const [termoBusca, setTermoBusca] = useState('');
    const [livros, setLivros]= useState([]);

    const handleSubmit = async(e)=>{
        e.preventDefault();
        try{
            const response = await fetch(`http://localhost:8080/buscarLivroPorTitulo/${termoBusca}`);
            const dados = await response.json();
            setLivros([dados]);
        }catch (error){
            console.error(error);
        }
    }
    return (
        <Div direcao = 'column'>
            <Titulo>Encontre seu proximo livro</Titulo>
            <Parragrafo>Explore por titulo o livro desejado</Parragrafo>
            <Input placeholder="Digite o nome de um livro..." value={termoBusca} onChange={(e)=> setTermoBusca(e.target.value)}/>
            <button onClick={handleSubmit} > Pesquisa </button>
            <Resultado livros = {livros}/>
        </Div>
    )
}

export default Pesquisa;