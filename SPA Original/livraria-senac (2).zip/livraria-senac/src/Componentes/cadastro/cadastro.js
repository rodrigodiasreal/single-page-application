import { type } from "@testing-library/user-event/dist/type";
import React, { useState } from "react";

const Cadastro = () => {
    const [formData,setFormData]=useState({name:'',password:''});
    const [feedBack,setFeedback]=useState({message:'', type:''});

    const handleChange = (e) => {
        const {name,value}=e.target;
        setFormData(prevState => ({...prevState,[name]: value}))
    }
    const handleSubmit = async (e) => {
        e.preventDefault();
        try{
            const response =await fetch('http://localhost:8080/addUser', {
            method:'POST',
            headers:{
                'Content-type': 'application/json'
            },
            body:JSON.stringify(formData)
        })
        if(response.ok){
            setFeedback({message: 'Cadastrado!', type:'sucesso'})
        }else{
            const erro =await response.json()
            setFeedback({message:erro.message, type:'erro'})
        }
            setFeedback({name:'',password:''})
        
        }catch(error){
                console.error(error)
                setFeedback({message:"Falha ao cadastrar",type:"erro"})
            }
        }

    }
    return(
        <div>
            <h1>Tela de Cadastro</h1>
            <form onSubmit={handleSubmit}>
                <div>
                <label>Nome:</label>
                    <input
                        type="text"
                        id="name"
                        value={formData.name}
                        onChange={handleChange}
                        required/>
                </div>
                <div>
                <label>Senha:</label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        required/>
                </div>
                <button type="submit">Cadastrar</button>
                {
                    feedBack.message && (
                        <div className={feedBack.type}>
                            {feedBack.message}
                        </div>
                    )
                }
            </form>

        </div>
       
    );
export default Cadastro;